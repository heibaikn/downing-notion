# 1110 vue3 array.concat超过1w个 失效

## 解决

使用 `array.push`