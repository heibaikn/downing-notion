# 0406 stable diffusion

[Installation on Apple Silicon](https://github.com/AUTOMATIC1111/stable-diffusion-webui/wiki/Installation-on-Apple-Silicon)

![Untitled](0406%20stable%20diffusion%20e8f3af0deb114b479eb57dc06a620e5e/Untitled.png)

1. `python3 -m pip install --upgrade pip`  升级pip

## pyenv

管理python版本