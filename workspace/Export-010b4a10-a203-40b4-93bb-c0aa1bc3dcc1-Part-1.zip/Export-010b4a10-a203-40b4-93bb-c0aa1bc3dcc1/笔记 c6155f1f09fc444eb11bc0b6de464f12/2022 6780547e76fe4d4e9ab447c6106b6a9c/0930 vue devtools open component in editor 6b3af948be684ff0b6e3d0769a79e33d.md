# 0930 vue devtools open component in editor

[Open component in editor | Vue Devtools](https://devtools.vuejs.org/guide/open-in-editor.html)

调用系统 `code ${path}` 命令 打开文件

![Untitled](0930%20vue%20devtools%20open%20component%20in%20editor%206b3af948be684ff0b6e3d0769a79e33d/Untitled.png)

## wsl 下无法打开目录

![Untitled](0930%20vue%20devtools%20open%20component%20in%20editor%206b3af948be684ff0b6e3d0769a79e33d/Untitled%201.png)

![Untitled](0930%20vue%20devtools%20open%20component%20in%20editor%206b3af948be684ff0b6e3d0769a79e33d/Untitled%202.png)

[https://github.com/vuejs/devtools/issues/1957](https://github.com/vuejs/devtools/issues/1957)