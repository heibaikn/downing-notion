# 0919 bilibili技术总结

[主服务+gmaster+CloudBuild](0919%20bilibili%E6%8A%80%E6%9C%AF%E6%80%BB%E7%BB%93%20270678facf2a49fabd6f7fdd85fa70e9/%E4%B8%BB%E6%9C%8D%E5%8A%A1+gmaster+CloudBuild%20e450386f5f1f4194b956f3a03019c3e9.md)

[文档](0919%20bilibili%E6%8A%80%E6%9C%AF%E6%80%BB%E7%BB%93%20270678facf2a49fabd6f7fdd85fa70e9/%E6%96%87%E6%A1%A3%20cacad767fc874d57b6d2dd256c8e9e6e.md)

[示例后台](0919%20bilibili%E6%8A%80%E6%9C%AF%E6%80%BB%E7%BB%93%20270678facf2a49fabd6f7fdd85fa70e9/%E7%A4%BA%E4%BE%8B%E5%90%8E%E5%8F%B0%2094a541e64b8945f08c952a3dffc15f4c.md)

[单体仓库 (`mono-repo`) 和多仓库 (`multi-repo`)](0919%20bilibili%E6%8A%80%E6%9C%AF%E6%80%BB%E7%BB%93%20270678facf2a49fabd6f7fdd85fa70e9/%E5%8D%95%E4%BD%93%E4%BB%93%E5%BA%93%20(mono-repo)%20%E5%92%8C%E5%A4%9A%E4%BB%93%E5%BA%93%20(multi-repo)%2004a1dca55c61442d8cc97f45497b10e1.md)

[乾坤+pnpm+vite+vue3](0919%20bilibili%E6%8A%80%E6%9C%AF%E6%80%BB%E7%BB%93%20270678facf2a49fabd6f7fdd85fa70e9/%E4%B9%BE%E5%9D%A4+pnpm+vite+vue3%20b9c046ed2cf94d9690e8a03a28790653.md)

[虚拟列表](0919%20bilibili%E6%8A%80%E6%9C%AF%E6%80%BB%E7%BB%93%20270678facf2a49fabd6f7fdd85fa70e9/%E8%99%9A%E6%8B%9F%E5%88%97%E8%A1%A8%206f2d6d5f3a614e3ea212bf47e274c1ed.md)