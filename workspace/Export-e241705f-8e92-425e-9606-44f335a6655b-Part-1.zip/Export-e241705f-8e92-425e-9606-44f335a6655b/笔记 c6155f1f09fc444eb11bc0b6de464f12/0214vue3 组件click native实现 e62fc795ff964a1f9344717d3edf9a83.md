# 0214vue3 组件click.native实现

## vue2 .native 修饰符

你可能有很多次想要在一个组件的根元素上直接监听一个原生事件。这时，你可以使用 `v-on`
 的 `.native`修饰符