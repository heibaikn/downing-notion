# 1222 WebAssembly hello world

[使用 docker 镜像](1222%20WebAssembly%20hello%20world%207ba145ad0dbb4425b119976eedeac87b/%E4%BD%BF%E7%94%A8%20docker%20%E9%95%9C%E5%83%8F%2059f60fafdba240d8ba1095c15cfeefc4.md)

[go webassembly 操作dom](1222%20WebAssembly%20hello%20world%207ba145ad0dbb4425b119976eedeac87b/go%20webassembly%20%E6%93%8D%E4%BD%9Cdom%205c693b29ba144149a3effd97dddd7e41.md)

[1222 golang 导出 webassembly](1222%20WebAssembly%20hello%20world%207ba145ad0dbb4425b119976eedeac87b/1222%20golang%20%E5%AF%BC%E5%87%BA%20webassembly%20d3999c87a96a4586ad140443f7ad5c49.md)