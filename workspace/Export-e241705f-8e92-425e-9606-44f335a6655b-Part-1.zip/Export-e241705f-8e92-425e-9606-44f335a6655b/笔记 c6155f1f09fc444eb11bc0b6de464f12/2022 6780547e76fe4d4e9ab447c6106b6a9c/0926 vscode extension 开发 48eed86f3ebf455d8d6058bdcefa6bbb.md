# 0926 vscode extension 开发

webpack 打包包含，vscode 开发 pai的 特殊包

脚手架

[Your First Extension](https://code.visualstudio.com/api/get-started/your-first-extension)

api

[VS Code API](https://code.visualstudio.com/api/references/vscode-api)