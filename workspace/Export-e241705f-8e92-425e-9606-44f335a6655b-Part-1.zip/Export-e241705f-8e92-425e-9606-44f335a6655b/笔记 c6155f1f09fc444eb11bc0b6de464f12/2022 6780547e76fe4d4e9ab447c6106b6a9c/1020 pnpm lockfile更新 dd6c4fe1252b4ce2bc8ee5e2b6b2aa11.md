# 1020 pnpm lockfile更新

[pnpm install | pnpm](https://pnpm.io/zh/cli/install#--frozen-lockfile)

pnpm i 时 输入 ci环境标识

```bash

# 不更新 lockfile 
pnpm i --frozen-lockfile
```