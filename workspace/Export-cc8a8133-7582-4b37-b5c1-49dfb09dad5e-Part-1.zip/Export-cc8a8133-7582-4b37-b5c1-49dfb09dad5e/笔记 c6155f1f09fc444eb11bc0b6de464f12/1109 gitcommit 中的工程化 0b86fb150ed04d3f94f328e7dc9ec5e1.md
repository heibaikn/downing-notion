# 1109 gitcommit 中的工程化

仅对staged的代码校验

- [ ]  完成代码风格统一
- [ ]  完成gitcommit校验
- [ ]  完成eslint校验

`eslint-define-config` Provide a `defineConfig` function for `.eslintrc.js`

@typescript-eslint/no-implied-eval

[lint](1109%20gitcommit%20%E4%B8%AD%E7%9A%84%E5%B7%A5%E7%A8%8B%E5%8C%96%200b86fb150ed04d3f94f328e7dc9ec5e1/lint%2050f270d6d943485d88b22664153afd1d.md)

[githook 自动prettier和lint](1109%20gitcommit%20%E4%B8%AD%E7%9A%84%E5%B7%A5%E7%A8%8B%E5%8C%96%200b86fb150ed04d3f94f328e7dc9ec5e1/githook%20%E8%87%AA%E5%8A%A8prettier%E5%92%8Clint%202f820b952672456186a83108c431714d.md)