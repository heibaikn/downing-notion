# 0425 nodesass 报错解决

## 使用 dartsass 替换nodesass

```bash
npm install node-sass@npm:dart-sass -D
```