# apache/apisix 开源项目

[https://github.com/apache/apisix-dashboard/issues](https://github.com/apache/apisix-dashboard/issues)