# dateFunc

## 天数计算

```jsx
var date = new Date('2022/06/01');
date.setDate(date.getDate()+100);
date.toLocaleDateString()
```