# 0915 stable diffusion

## docker 启动

[https://github.com/fboulnois/stable-diffusion-docker](https://github.com/fboulnois/stable-diffusion-docker)

```bash

./build.sh pull
## vim token.txt 
./build.sh build
```

## window