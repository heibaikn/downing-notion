# 1025 vscode typescript 类型自动import

在vscode 中输入工程下的 类型，可选择自动补全

![Untitled](1025%20vscode%20typescript%20%E7%B1%BB%E5%9E%8B%E8%87%AA%E5%8A%A8import%206bfa55d5a44b4e24a966bc1e829cb05e/Untitled.png)

![Untitled](1025%20vscode%20typescript%20%E7%B1%BB%E5%9E%8B%E8%87%AA%E5%8A%A8import%206bfa55d5a44b4e24a966bc1e829cb05e/Untitled%201.png)