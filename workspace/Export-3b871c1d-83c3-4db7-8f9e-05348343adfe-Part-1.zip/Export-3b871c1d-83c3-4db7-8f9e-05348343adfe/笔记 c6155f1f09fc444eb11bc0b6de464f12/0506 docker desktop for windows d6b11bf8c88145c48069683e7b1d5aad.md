# 0506 docker desktop for windows

## install

[Windows 10](https://yeasy.gitbook.io/docker_practice/install/windows)