# milestone

### **0.15**

1. 【gtc】【doc】提供文档组件:视频,图片,轮播图
2. 【gmaster】表单引擎/新增按钮和json设计器
3. 【gmaster】表单引擎/下拉选项允许设定选项值
4. 【gmaster】表单引擎/数据关联的视图使用了分页新增远程搜索
5. 【gmaster】数据视图批量操作
6. 【gmaster】数据视图字段新增排序和刷选功能
7. 【gmaster】流程引擎/新增流程分支拷贝
8. 【gmaster】表单引擎/monaco替换原有Json编辑器
9. 【gmaster】流程视图详情中的webhook返回提供格式化
10. 【CloudBuild】构建历史页/构建记录支持新标签页打开页面
11. 【CloudBuild】云构建自定义步骤支持自定义名称
12. 【运营】支持天数 8天
13. 

### **0.14**

1. 【gtc】【doc】提供文档组件:视频,图片,轮播图
2. 【gmaster】视图引擎/数据视图 新增关闭主动查询方式
3. 【gmaster】视图引擎/数据视图 过滤功能优化
4. 【CloudBuild】iOS签名步骤重构及支持P12证书
5. 【CloudBuild】证书中心本地签名模式teamid自动化填写
6. 【CloudBuild】云构建自定义步骤支持自定义名称
7. 【CloudBuild】“我要构建”页新增构建配置
8. 【运营】支持天数 9天

### **0.13**

1. 【gtc】 添加 `gcloud.biligame.com` 域名支持
2. 【gtc】对前端构建实现一包多环境且对产物进行分包
3. 【gmaster】流程引擎 支持分支
4. 【gmaster】视图引擎 支持模板功能
5. 【gmaster】视图引擎 支持一单元格多控件
6. 【gmaster】视图引擎 新增通过url打开记录详情
7. 【gmaster】视图引擎 新增webhook 异常对非研发可见
8. 【CloudBuild】增加Windows镜像支持
9. 【CloudBuild】启动构建时可以选择管道步骤
10. 【CloudBuild】构建配置支持复制
11. 【运营】支持天数 9天

### 0.12 milestone

1. 前端构建迁移从rider 迁移到nyx
2. Gmaster G10运营支持
3. Gmaster 流程引擎使用svg重构，并支持分支 (V1)
4. Gmaster response script 添加 download 辅助函数
5. CloudBuild 自定义环境变量使用了保留变量时应该有警告
6. CloudBuild 构建环境页支持json数据导出

0.11 milestone~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Gmaster 进程中心
2. CloudBuild新增pc/windows 构建
3. CloudBuild环境变量支持分支选择器
4. CloudBuild执行阶段追加自定义前置脚本
5. 通用组件 select-filter (V1)

0.10 milestone~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. 新增概览页面，支持一键式构建
2. 新增计划构建功能（含定时构建）
3. 新增报错分析功能
4. 全新的构建配置系统 editconfig-step
5. 在构建历史中显示错误诊断数据
6. 证书中心，安卓证书输入方式统一为路径文件访问的方式
7. 构建历史标题允许自定义修改

0.9 milestone~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. 文档系统
2. web前端CICD优化
3. web依赖管理工具pnpm
4. 构建详情/工作区目录
5. 多工件捕获
6. 用户需求类

构建历史重构行为可修改变量

git分支动态获取

前后运行环境动态输入

构建变量新增多选类型

0.8 milestone~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. QAQ 平台自动发布
2. 云构建证书中心
3. 云构建，增加管道构建页面
4. 构建详情
    1. 构建环境 云构建前端添加构建参数信息显示()
    2. 更变记录
    3. 步骤分析 Unity 日志步骤与拆分()
    4. 构建日志 patch更新 & 大小写 敏感/忽略
5. AssetBundle包的缓存机制
6. 重构: 配置页
7. Pnpm 构建
8. Docusaurus 文档初始化

0.7 milestone~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. 新版本: 配置编辑页
2. 新版本：构建history页&详情页
3. 构建详情 tab:
    1. 构建日志 虚拟列表&ctrl+f & ansi
    2. 详情页 tab: 磁盘分析
    3. 详情页 tab: 资产分析
    4. 详情页 tab: 依赖分析
    5. 详情页 tab: 工作制品
4. 数据大盘